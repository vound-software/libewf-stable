/*
 * EWF table section
 *
 * Copyright (c) 2006-2014, Joachim Metz <joachim.metz@gmail.com>
 *
 * Refer to AUTHORS for acknowledgements.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

#if !defined( _EWF_TABLE_H )
#define _EWF_TABLE_H

#include <common.h>
#include <types.h>

#if defined( __cplusplus )
extern "C" {
#endif

typedef struct ewf_table_header ewf_table_header_t;

struct ewf_table_header
{
	/* The number of offsets
	 * consists of 4 bytes (32 bits)
	 */
	uint8_t number_of_offsets[ 4 ];

	/* Padding
	 * consists of 4 bytes
	 * value should be 0x00
	 */
	uint8_t padding1[ 4 ];

	/* The base offset
	 * consists of 8 bytes
	 */
	uint8_t base_offset[ 8 ];

	/* Padding
	 * consists of 4 bytes
	 * value should be 0x00
	 */
	uint8_t padding2[ 4 ];

	/* The section checksum of all (previous) table data
	 * consists of 4 bytes
	 * starts with offset 76
	 */
	uint8_t checksum[ 4 ];

	/* The offset array
	 * consists of mulitple 4 byte offsets
	 */

	/* The last offset is followed by a 4 byte checksum
	 */
};

typedef struct ewf_table_offset ewf_table_offset_t;

struct ewf_table_offset
{
	/* An offset
	 * consists of 4 bytes
	 */
	uint8_t offset[ 4 ];
};

#if defined( __cplusplus )
}
#endif

#endif

